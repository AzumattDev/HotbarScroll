| `Version` | `Update Notes`                                                                    |
|-----------|-----------------------------------------------------------------------------------|
| 1.0.1     | - Add Inverted Scroll configuration option for those Minecraft players out there. |
| 1.0.0     | - Initial Release                                                                 |